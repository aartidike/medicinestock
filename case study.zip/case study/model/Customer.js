const mongoose = require('mongoose');

var Schema = mongoose.Schema;

var customersSchema = new Schema({
    username: {type:String,required:true},
    password: { type: String },
    address:String,
  //  customer:{type:String,required:true}

});

//module.exports = mongoose.model('Customer', customersSchema);
module.exports =
    mongoose.models.Customer || mongoose.model('Customer', customersSchema);


// const customerSchema = new mongoose.Schema({
//     name:String,
//   username: { type: String, unique: true },
//   password: { type: String },
//   address:String,
//   state:String,
//   country:String,
// 	email:String,
// 	pan:String,
// 	contact:String,
// 	dob:String,
//   account_type:String,
//   token: { type: String },
// });

// module.exports = mongoose.model("customer", customerSchema);
